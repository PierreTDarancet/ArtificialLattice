# Introduction to Computational Quantum Nanoelectronics

This is a collection of Jupyter notebooks that formed the bulk of the
["Introduction to Conmputational Quantum
Nanoelectronics"](http://www.aps.org/meetings/march/events/tutorials.cfm#t10)
tutorial given at the 2016 APS March Meeting.

[![Binder](http://mybinder.org/badge.svg)](http://mybinder.org/repo/kwant-project/kwant-tutorial-2016)
